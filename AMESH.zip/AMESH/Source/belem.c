#include	"amesh.h"

#define	NULL	((char *)0)

extern	struct	locat	*locat;

struct	bound *bstar(/* struct locat * */);

struct	bound *
belem(l,abp)
	struct	locat	*l, **abp;
{
	struct	locat	*o;
	struct	bound	*b0, *b1, *bc, *b;
	int	flag;
	double	dx, dy, c, c1, c2, c3;

	*abp = (struct locat *)NULL;
/*
 * create a known bounding polygon
 */
	b0 = bstar(l);
	for(o = locat; o; o = o->l_next) {
		if(o == l) continue;
		dx = (o->l_x -l->l_x);
		dy = (o->l_y -l->l_y);
		c = (dx*dx + dy*dy)/2;
		if(c == 0.0) {
			if(o->l_z <= l->l_z) continue;
			if(*abp && (*abp)->l_z <= o->l_z) continue;
			*abp = o;
			continue;
		}
		c += dx*l->l_x + dy*l->l_y;
/*
 *  locate a vertex inside the connection
 */
		b = b0;
		bc = (struct bound *)NULL;
		flag = 0;
		do {
			if(b->b_other &&
			   b->b_other->l_x == o->l_x &&
			   b->b_other->l_y == o->l_y) {
				flag = 1;
				if(o->l_layer == l->l_layer)
					b->b_other = o;
			}
			if(!bc && dx*b->b_x + dy*b->b_y <= c)
				bc = b;
			b = b->b_next;
		} while(b != b0);
		if(flag) continue;
		if(!bc) continue;
		for(b = b0 = bc; (b = b->b_next) != b0; bc = b) {
/*
 *  locate a boundary segment intersected by the line
 */
			if(dx*b->b_x + dy*b->b_y <= c) continue;
			if((b1 = (struct bound *)malloc(sizeof(*b))) == (struct bound *)NULL) {
				perror("malloc-beleme"); exit(1);
			}
			bc->b_next = b1;
			c1 = dx*bc->b_x + dy*bc->b_y;
			c2 = dx*b->b_x  + dy*b->b_y;
			c3 = (c - c1)/(c2 - c1);
			b1->b_other = o;
			b1->b_x = bc->b_x + (b->b_x - bc->b_x)*c3;
			b1->b_y = bc->b_y + (b->b_y - bc->b_y)*c3;
			for(bc = b; (b = b->b_next) != b0; bc = b) {
				if(dx*b->b_x + dy*b->b_y <= c) break;
				(void)free((char *) bc);
			}
			b1->b_next = bc;
			c1 = dx*bc->b_x + dy*bc->b_y;
			c2 = dx*b->b_x  + dy*b->b_y;
			c3 = (c - c1)/(c2 - c1);
			bc->b_x = bc->b_x + (b->b_x - bc->b_x)*c3;
			bc->b_y = bc->b_y + (b->b_y - bc->b_y)*c3;
			if(b == b0) break;
		}
	}
	return(b0);
}
