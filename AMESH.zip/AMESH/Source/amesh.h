struct	locat	{
	char	l_name[6];
	short	l_layer;
	double	l_x,l_y,l_z;
	double	l_thick;
	struct	locat	*l_next;
};

struct	bound	{
	struct	bound	*b_next;
	struct	locat	*b_other;
	double	b_x,b_y;
};
