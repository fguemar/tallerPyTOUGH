#include	"amesh.h"

#define	NULL	((char *)0)

extern	struct	locat	*locat;
extern	struct	bound	*bound;

void
extre()
{
	double	xl, yl, xh, yh;
	struct	locat	*l;

	if(bound) return;
	bound = (struct bound *)malloc(4*sizeof(struct bound)); 
	if(bound == (struct bound *)NULL) {
		perror("extre-malloc"); exit(1);
	}
	xh = xl = locat->l_x;
	yh = yl = locat->l_y;
	for(l = locat->l_next; l; l = l->l_next) {
		if(xl > l->l_x) xl = l->l_x;
		if(xh < l->l_x) xh = l->l_x;
		if(yl > l->l_y) yl = l->l_y;
		if(yh < l->l_y) yh = l->l_y;
	}
	bound[0].b_next = &bound[1];
	bound[0].b_other = (struct locat *)NULL;
	bound[0].b_x = xl;
	bound[0].b_y = yl;
	bound[1].b_next = &bound[2];
	bound[1].b_other = (struct locat *)NULL;
	bound[1].b_x = xh;
	bound[1].b_y = yl;
	bound[2].b_next = &bound[3];
	bound[2].b_other = (struct locat *)NULL;
	bound[2].b_x = xh;
	bound[2].b_y = yh;
	bound[3].b_next = bound;
	bound[3].b_other = (struct locat *)NULL;
	bound[3].b_x = xl;
	bound[3].b_y = yh;
}
