#include	<stdio.h>

struct	locat	*locat;
struct	bound	*bound;
double	toler = 0.;

void
main()
{
	FILE	*fp;

	if((fp = fopen("in","r")) == NULL) {
		perror("in-open"); exit(1);
	}
	rmesh(fp);
	(void)fclose(fp);
	if(!locat) exit(1);
	extre();
	pmesh();
}
