#include	<stdio.h>
#include	<math.h>

#include	"amesh.h"

extern	struct	locat	*locat;
extern	double	toler;

struct	bound	*belem(/* struct locat *, struct locat ** */);

void
pmesh()
{
	FILE	*ef,*cf,*sf;
	struct	bound	*b, *b1, *b2;
	struct	locat	*above, *l, *j;
	double	vol, area, dx, dy, dz, beta, a;
	double	d1, d2;
	int	nb = 0;
	int	k;
	char	*cp;
	char	bnd[6];

	if((ef = fopen("eleme","w")) == NULL) {
		perror("open-eleme"); exit(1);
	}
	if((cf = fopen("conne","w")) == NULL) {
		perror("open-conne"); exit(1);
	}
	if((sf = fopen("segmt","w")) == NULL) {
		perror("open-eleme"); exit(1);
	}
	(void)fprintf(ef,"eleme\n");
	(void)fprintf(cf,"conne\n");
	for(l = locat; l; l= l->l_next) {
		vol = 0.0;
		area = 0.0;
		b = belem(l,&above);
		for(b1 = b, b2 = NULL; !b2 || b1 != b; b1 = b2) {
			double	vp;
			b2 = b1->b_next;
			dx = b2->b_x - b1->b_x;
			dy = b2->b_y - b1->b_y;
			d2 = dx*dx + dy*dy;
			if(d2 == 0.0) continue;
			if(d2 < toler) {
				d2 = 0;
				continue;
			}
			d2 = sqrt(d2);
			d1 = dy*(b1->b_x - l->l_x) - dx*(b1->b_y - l->l_y);
			if(d1 < 0.0) d1 = -d1;
			d1 /= d2;
			j = b1->b_other;
			beta = 0;
			k = 0;
			if(j && j->l_layer ==  l->l_layer) {
				a = d2*(l->l_thick + j->l_thick)/2;
				vp = a*d1/3 + d1*d2*l->l_thick/6;
				area += d1*d2/2;
				cp = j->l_name;
				if(j > l) {
					k = 1;
					dz = j->l_z - l->l_z;
					beta = dz / sqrt(4*d1*d1 + dz*dz);
					d2 = d1;
				}
			}
			else {
				if(d1 == 0.0 || j) {
					cp = "*   0";
					a = 0.;
					vp = d1*d2*l->l_thick/6;
					area += d1*d2/2;
					d2 = 0.;
				}
				else {
					a = d2*l->l_thick;
					vp = a*d1/2;
					area += d1*d2/2;
					d2 = 0;
					(void)sprintf(cp = bnd,"*%4d",++nb);
				}
				j = NULL;
			}
			vol += vp;
			(void)fprintf(sf,
			    "%15.9g%15.9g%15.9g%15.9g  %d  %-5.5s%-5.5s\n",
			    b1->b_x,b1->b_y,
			    b2->b_x,b2->b_y,
			    k,l->l_name,cp);
			if(j && !k) continue;
			(void)fprintf(cf,
			    "%-5.5s%-5.5s                   1%10.3e%10.3e%10.3e",
			    l->l_name,
			    cp,
			    d1,d2,a);
			if(beta != 0.0) (void)fprintf(cf,"%10.3e\n",beta);
			else (void)fprintf(cf,"\n");
		}
		if(above) {
			(void)fprintf(cf,
			    "%-5.5s%-5.5s                   1%10.3e%10.3e%10.3e 1.\n",
			    l->l_name,
			    above->l_name,
			    l->l_thick/2,above->l_thick/2,area);
		}
		(void)fprintf(ef,
		    "%-5.5s          rock1%10.3e                    %13.6e%13.6e%13.6e\n",
		    l->l_name,
		    vol,l->l_x,l->l_y,l->l_z);
		for(b1 = b, b2 = NULL; b1 != b && !b2; b1 = b2) {
			b2 = b1->b_next;
			(void)free(b1);
		}
	}
	(void)fprintf(ef,"\n");
	(void)fprintf(cf,"\n");
	(void)fclose(ef);
	(void)fclose(cf);
	(void)fclose(sf);
}
