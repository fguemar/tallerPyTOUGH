#include	"amesh.h"

#define	NULL	((char *)0)

extern	struct	bound	*bound;

char	*malloc(/* unsigned int */);

/*
 * create a known bounding polygon
 */
struct	bound	*
bstar(l)
	struct	locat	*l;
{
	struct	bound	*b0, *b, *b1, *bc;
	struct	bound	**bp;
	double	d0, d, dx, dy;

	bp = &b0;
	bc = (struct bound *)NULL;
	b = bound;
	do {
		if(((*bp) = (struct bound *)malloc(sizeof(*b))) == (struct bound *)NULL) {
			perror("bstar-malloc"); exit(1);
		}
		**bp = *b;
		dx = b->b_x - l->l_x;
		dy = b->b_y - l->l_y;
		d = dx*dx + dy*dy;
		if(!bc || d0 > d) {
			bc = *bp;
			d0 = d;
		}
		bp = &(*bp)->b_next;
		b = b->b_next;
	} while(b != bound);
	*bp = b0;
	return(bc);
}
