#include	<stdio.h>
#include	<ctype.h>

#include	"amesh.h"

extern	struct	locat	*locat;
extern	struct	bound	*bound;
extern	double	toler;

void	rmesh(fp)
	FILE	*fp;
{
	char	buf[1024];
	char	*cp;
	struct	locat	**l = &locat;
	struct	bound	**b = &bound;

/*
 * this subroutine reads in the mesh information i.e. the element
 * coordinates, connection distances, and any boundary description.
 */

/*
 * what kind of block have we encountered (ignore any unknown)
 */
	while((cp = fgets(buf, 1024, fp)) != NULL) {
/*
 * put into lower case (upper case gives me a headache)
*/
		for(; *cp && cp < buf + 5; cp++)
			if(isupper(*cp)) *cp = tolower(*cp);
/*
 * the location block -- read until you find a blank element name
*/
		if(!locat && strncmp(buf,"locat",5) == 0) for(;;) {
			double	x,y,z,thick;
			int	layer;

			if((cp = fgets(buf,1024,fp)) == NULL) return;
			for(; isspace(*cp); cp++) ;
			if(cp >= buf + 5 || *cp == '\0') break;
			if((*l = (struct locat *)malloc(sizeof(**l))) == NULL) {
				perror("locat-malloc"); exit(1);
			}
			(*l)->l_next = NULL;
			strncpy((*l)->l_name,buf,5);
			sscanf(buf+5,"%d %lf %lf %lf %lf",
				&layer,
				&x,
				&y,
				&z,
				&thick);
			(*l)->l_layer = layer;
			(*l)->l_x = x;
			(*l)->l_y = y;
			(*l)->l_z = z;
			(*l)->l_thick = thick;
			l = &(*l)->l_next;
		}
/*
 * the boundary block -- how do i draw the mesh
*/
		else if(!bound && strncmp(buf,"bound",5) == 0) for(;;) {
			if((cp = fgets(buf,1024,fp)) == NULL) return;
			for(; isspace(*cp); cp++) ;
			if(cp >= buf + 10 || *cp == '\0') break;
			if(((*b) = (struct bound *)malloc(sizeof(**b))) == NULL) {
				perror("bound-malloc"); exit(1);
			}
			(*b)->b_next = bound;
			(*b)->b_other = NULL;
			sscanf(buf,"%lf %lf",
				&(*b)->b_x,
				&(*b)->b_y);
			b = &(*b)->b_next;
		}
		else if(!toler && strncmp(buf,"toler",5) == 0) {
			if(fgets(buf,1024,fp) == NULL) return;
			sscanf(buf,"%lf",&toler);
			toler *= toler;
		}
/*
 * if we have all the information we want, we can stop reading
*/
		if(locat && bound && toler) return;
	}
}
